export const AppColors = {
    primary: '#24A8AF',
    primeryLight: '#039ba3',
    secondary: '#2c2c6c',
    white: '#fff',
    black: '#000',
    lightGray: '#f5f5f5',
}