const ScreenNames = {
  DrawerHome: 'DrawerHome',
  HOME: "Home",
  LOGIN: "Login",
  SIGNUP: "Signup",
  DRAWER: "Drawer",
  ROUTE: "Route",
  ABOUTUS: "AboutUs",
  DETECTION: "Detection",
  FEATURES: 'Features'
};

export default ScreenNames;
